// LeadForge — Shared JS

// Mobile nav toggle
function initNav() {
  const toggle = document.querySelector('.nav-toggle');
  const links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', () => links.classList.toggle('open'));
  }
}

// Smooth scroll
function initScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth' }); }
    });
  });
}

// Tab switching
function switchTab(id, btn, prefix) {
  const p = prefix || 'tab-';
  document.querySelectorAll('.tab-panel').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
  document.getElementById(p + id).classList.add('active');
  btn.classList.add('active');
}

// CTA form submit
function handleCTA(e) {
  const btn = e.target.closest('button');
  const form = btn.closest('.cta-section') || btn.closest('section');
  const name = form.querySelector('input[type="text"]')?.value.trim();
  const phone = form.querySelector('input[type="tel"]')?.value.trim();
  if (name && phone) {
    btn.textContent = '✓ Locked in — we\'ll call you within 24hrs';
    btn.style.background = '#16a34a';
    btn.style.cursor = 'default';
    btn.disabled = true;
  } else {
    form.querySelectorAll('input').forEach(i => { if (!i.value.trim()) i.style.borderColor = '#ef4444'; });
  }
}

// Booking widget
let selectedType = null;
let selectedTime = null;

function selectBookingType(el, type) {
  document.querySelectorAll('.booking-option').forEach(o => o.classList.remove('selected'));
  el.classList.add('selected');
  selectedType = type;
}

function selectTime(el, time) {
  document.querySelectorAll('.time-slot').forEach(o => o.classList.remove('selected'));
  el.classList.add('selected');
  selectedTime = time;
}

function submitBooking(btn) {
  const form = btn.closest('.booking-wrap') || btn.closest('section');
  const inputs = form.querySelectorAll('.booking-form input');
  const name = inputs[0]?.value.trim();
  const phone = inputs[1]?.value.trim();
  if (name && phone && selectedType && selectedTime) {
    btn.textContent = '✓ Booked! Check your phone for confirmation';
    btn.style.background = '#16a34a';
    btn.disabled = true;
  } else {
    if (!selectedType) alert('Please select a call type');
    else if (!selectedTime) alert('Please pick a time slot');
    else { inputs.forEach(i => { if (!i.value.trim()) i.style.borderColor = '#ef4444'; }); }
  }
}

// Calculator engine
const TRADE_DATA = {
  plumber: { jobValue: 650, jobsPerMonth: 22, missedCallRate: 0.38, leadToJob: 0.28, costPerLead: 55 },
  electrician: { jobValue: 420, jobsPerMonth: 28, missedCallRate: 0.35, leadToJob: 0.30, costPerLead: 48 },
  painter: { jobValue: 2200, jobsPerMonth: 8, missedCallRate: 0.42, leadToJob: 0.22, costPerLead: 70 },
  builder: { jobValue: 18000, jobsPerMonth: 3, missedCallRate: 0.30, leadToJob: 0.18, costPerLead: 120 },
  dentist: { jobValue: 380, jobsPerMonth: 180, missedCallRate: 0.25, leadToJob: 0.45, costPerLead: 35 },
  physio: { jobValue: 120, jobsPerMonth: 220, missedCallRate: 0.22, leadToJob: 0.55, costPerLead: 25 },
  lawyer: { jobValue: 3200, jobsPerMonth: 12, missedCallRate: 0.28, leadToJob: 0.20, costPerLead: 95 },
  accountant: { jobValue: 1800, jobsPerMonth: 18, missedCallRate: 0.30, leadToJob: 0.25, costPerLead: 65 }
};

function calcROI() {
  const trade = document.getElementById('calc-trade')?.value;
  const spend = parseFloat(document.getElementById('calc-spend')?.value) || 2000;
  const data = TRADE_DATA[trade] || TRADE_DATA.plumber;

  const leadsPerMonth = Math.round(spend / data.costPerLead);
  const currentJobs = Math.round(leadsPerMonth * data.leadToJob);
  const improvedLeadToJob = Math.min(data.leadToJob * 1.9, 0.75);
  const missedCallRecovery = Math.round(data.missedCallRate * currentJobs * 0.6);
  const newJobs = Math.round(leadsPerMonth * improvedLeadToJob) + missedCallRecovery;
  const extraRevenue = Math.round((newJobs - currentJobs) * data.jobValue);
  const roi = Math.round(extraRevenue / spend * 10) / 10;

  document.getElementById('r-leads').textContent = leadsPerMonth;
  document.getElementById('r-jobs').textContent = newJobs;
  document.getElementById('r-revenue').textContent = '$' + extraRevenue.toLocaleString();
  document.getElementById('r-roi').textContent = roi + 'x';

  const panel = document.getElementById('calc-result');
  if (panel) panel.style.display = 'grid';
}

document.addEventListener('DOMContentLoaded', () => {
  initNav();
  initScroll();
  // Auto-run calc if on page with calculator
  if (document.getElementById('calc-trade')) calcROI();
});
